import { cannabis } from "../../support/cannabis.po"

describe('cannabis', () => {
    it('should be to resume  the plan', ()=>{
      cy.visit('https://dispensed.scssconsultingapps.com.au/accounts/login/')
      
      cannabis.Email().type("sandesh@scssconsulting.com")
      cannabis.Password().type('hellonepal')
       cannabis.clickButton().click({force:true})
       cy.contains('Cannabis Products').click() 
       cy.contains('Please resume my treatment plan').click()
    //    cy.scrollTo('bottom')
    })
    it('should be to change the quantaty ', ()=>{
        cy.visit('https://dispensed.scssconsultingapps.com.au/accounts/login/')
        
        cannabis.Email().type("sandesh@scssconsulting.com")
        cannabis.Password().type('hellonepal')
         cannabis.clickButton().click({force:true})
         cy.contains('Cannabis Products').click() 
         cannabis.updateGgrams().select('40 grams')
cy.contains('Submit').click()          
      })

      it('should be to deactive the plan ', ()=>{
        cy.visit('https://dispensed.scssconsultingapps.com.au/accounts/login/')
        
        cannabis.Email().type("sandesh@scssconsulting.com")
        cannabis.Password().type('hellonepal')
         cannabis.clickButton().click({force:true})
         cy.contains('Cannabis Products').click() 
         cy.contains('Please deactivate my treatment plan').click() 

})

})