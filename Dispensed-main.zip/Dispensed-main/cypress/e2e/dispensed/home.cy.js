import { Home } from "../../support/dispensed/home.po"

describe('Home pages', () => {
    it('should land to dashboard', ()=>{
      cy.visit('https://dispensed.scssconsultingapps.com.au/accounts/login/')
      
      Home.Email().type("sandesh@test.com")
      Home.Password().type('hellonepal')
       Home.clickButton().click({force:true})
       cy.url().should('eq', 'https://dispensed.scssconsultingapps.com.au/patient/dashboard/') // => true
       



    })
    it('contains to dashboard', ()=>{
        cy.visit('https://dispensed.scssconsultingapps.com.au/accounts/login/')
        
        Home.Email().type("sandesh@test.com")
        Home.Password().type('hellonepal')
         Home.clickButton().click({force:true})
        cy.get('[class="btn btn-light w-100 text-center fw-bold p-3 rounded-pill border-0"]') .should('contain', 'Track Your Prescription')
        cy.get('[class="btn btn-light w-100 text-center fw-bold p-3 rounded-pill border-0"]') .should('contain', 'Discount Your treatment')
        cy.get('[class="btn btn-light w-100 text-center fw-bold p-3 rounded-pill border-0"]') .should('contain', 'Try Our Dry-Herb Vaporise')
        cy.get('[class="custom_open_order_heading"]').should('contain','Treatment plan progress')







})
it('should go to subscribtion page', ()=>{
    cy.visit('https://dispensed.scssconsultingapps.com.au/accounts/login/')
    
    Home.Email().type("sandesh@test.com")
    Home.Password().type('hellonepal')
     Home.clickButton().click({force:true})
     cy.contains('Update Subscription').click()
     cy.url().should('eq', 'https://dispensed.scssconsultingapps.com.au/patient/subscription/update/') // => true

})
it('should go to account page', ()=>{
    cy.visit('https://dispensed.scssconsultingapps.com.au/accounts/login/')
    
    Home.Email().type("sandesh@test.com")
    Home.Password().type('hellonepal')
     Home.clickButton().click({force:true})
     cy.contains('Account Info').click()
     cy.url().should('eq', 'https://dispensed.scssconsultingapps.com.au/accounts/edit/') // => true

})
it('should go to billing page', ()=>{
    cy.visit('https://dispensed.scssconsultingapps.com.au/accounts/login/')
    
    Home.Email().type("sandesh@test.com")
    Home.Password().type('hellonepal')
     Home.clickButton().click({force:true})
     cy.contains('Billing History').click()
     cy.url().should('eq', 'https://dispensed.scssconsultingapps.com.au/patient/billing/') // => true

})
})