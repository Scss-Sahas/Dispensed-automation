import { consulation } from "../../support/dispensed/consulation.po"

describe('consulation', () => {
    it('should be able to book date', ()=>{
      cy.visit('https://app.dispensed.com.au/accounts/login/')
      
      consulation.Email().type("sandesh@scssconsulting.com")
      consulation.Password().type('hellonepal')
       consulation.clickButton().click({force:true})
       cy.contains('Consultation').click() 
    //consulation.submitButton().scrollTo('bottom')
    // cy.get('[".d-md-flex > :nth-child(1) > #menu > .nav-active-link > .nav-link > .text-white"]')
    cy.contains('Select a Date & Time').click()
    })})