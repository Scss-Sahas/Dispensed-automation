export class Profile{
        static Email =() => cy.get('[id="id_username"]')
        static Password =() => cy.get('[name="password"]')
        static clickButton =() => cy.get('[id="submit-id-"]')
        static csrf=() => cy.get('[name="csrfmiddlewaretoken"]')
       static firstName =() => cy.get('[name="first_name"]')
       static lastName =() => cy.get('[name="last_name"]')
     static saveButton =() => cy.get('[type="submit"]')
     static selectDob =() => cy.get('[id="div_id_dob"]')
           
       }
    
