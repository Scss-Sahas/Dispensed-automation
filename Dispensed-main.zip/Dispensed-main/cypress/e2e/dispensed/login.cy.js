import { Login } from "../../support/dispensed/login.po"

describe('Login', () => {
    it('login failure', ()=>{
      cy.visit('https://dispensed.scssconsultingapps.com.au/accounts/login/')
      
      Login.Email().type("sandesh@test.co")
      Login.Password().type('hellonepal')
       Login.clickButton().click({force:true})
      cy.url().should('eql','https://dispensed.scssconsultingapps.com.au/accounts/login/')



    })
    it('login pass', ()=>{
      cy.visit('https://dispensed.scssconsultingapps.com.au/accounts/login/')
      
      Login.Email().type("sandesh@test.com")
      Login.Password().type('hellonepal')
       Login.clickButton().click({force:true})
      cy.url().should('eql','https://dispensed.scssconsultingapps.com.au/patient/dashboard/')
    

  })
})