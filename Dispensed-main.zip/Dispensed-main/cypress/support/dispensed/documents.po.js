export class docs{
    static Email =() => cy.get('[id="id_username"]')
    static Password =() => cy.get('[name="password"]')
    static clickButton =() => cy.get('[id="submit-id-"]')
    static csrf=() => cy.get('[name="csrfmiddlewaretoken"]')
    static downloadButton=() => cy.get('[class="card bg-white d-flex flex-column align-items-start curved-1"]')

}