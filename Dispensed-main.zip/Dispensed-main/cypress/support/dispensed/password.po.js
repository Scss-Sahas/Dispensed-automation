export class Password{
    static Email =() => cy.get('[id="id_username"]')
    static Password =() => cy.get('[name="password"]')
    static clickButton =() => cy.get('[id="submit-id-"]')
    static csrf=() => cy.get('[name="csrfmiddlewaretoken"]')
    static oldPassword=() => cy.get('[name="old_password"]')
    static newPassword=() => cy.get('[name="new_password1"]')
    static conformPassword=() => cy.get('[name="new_password2"]')
    static saveChanges=() => cy.get('[type="submit"]')



   }
