import { Password } from "../../support/dispensed/password.po"

describe('Profile', () => {
    it('should update new password', ()=>{
      cy.visit('https://dispensed.scssconsultingapps.com.au/accounts/login/')
      
      Password.Email().type("sandesh@test.com")
      Password.Password().type('hellonepal')
       Password.clickButton().click({force:true})
       cy.contains('Profile').click()
       cy.contains('Password').click()
       Password.oldPassword().type('hellonepal')
       Password.newPassword().type('hellonepal@1')
       Password.conformPassword().type('hellonepal@1')

    })
    it('should be able to login with new password', ()=>{
        cy.visit('https://dispensed.scssconsultingapps.com.au/accounts/login/')
        
        Password.Email().type("sandesh@test.com")
        Password.Password().type('hellonepal')
         Password.clickButton().click({force:true})
        














})
})
