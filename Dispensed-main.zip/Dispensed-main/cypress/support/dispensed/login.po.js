export class Login{

 static Email =() => cy.get('[id="id_username"]')
 static Password =() => cy.get('[name="password"]')
 static clickButton =() => cy.get('[id="submit-id-"]')
 static csrf=() => cy.get('[name="csrfmiddlewaretoken"]')
static profile =() => cy.get('[class="position-relative nav-active-link mb-2 mb-md-3 w-100"]')
    
}