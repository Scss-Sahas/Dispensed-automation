export class cannabis{

    static Email =() => cy.get('[id="id_username"]')
    static Password =() => cy.get('[name="password"]')
    static clickButton =() => cy.get('[id="submit-id-"]')
    static csrf=() => cy.get('[name="csrfmiddlewaretoken"]')
    static updateGgrams =() => cy.get('[name="Indica-Flower"]')
    static submit=() => cy.get('[type="submit"]')
       
   }