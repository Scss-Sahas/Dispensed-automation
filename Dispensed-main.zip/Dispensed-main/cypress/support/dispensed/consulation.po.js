export class consulation{
    static Email =() => cy.get('[id="id_username"]')
    static Password =() => cy.get('[name="password"]')
    static clickButton =() => cy.get('[id="submit-id-"]')
    static csrf=() => cy.get('[name="csrfmiddlewaretoken"]')
    static  bookAppointment =()=> cy.get('[data-qa="animate"]')
   // data-testid="calendar"
   static  bookDate =()=> cy.get('[aria-label="Go to previous month"]')
  // data-qa="submit-button deep-purple-submit-button"
  static  submitButton =()=> cy.get('[class="calendly-inline-widget"]')


}