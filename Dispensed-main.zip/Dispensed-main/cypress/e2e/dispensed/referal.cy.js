import { referal } from "../../support/dispensed/referal.po"

describe('Profile', () => {
    it('should be able to check contains of Dashboard', ()=>{
      cy.visit('https://dispensed.scssconsultingapps.com.au/accounts/login/')
      
      referal.Email().type("sandesh@test.com")
      referal.Password().type('hellonepal')
       referal.clickButton().click({force:true})
       cy.contains('Discount my Treatment').click()
       //cy.get('')
      //cy.get('[class="stat-block stat-type-referrals"]') .should('contain', 'REFERRALS')
    //    .should('contain','CLICKS')
    //    .should('contain','UNPAID EARNINGS')
    //    .should('contain','Share this referral link to your friends and followers')
    cy.contains('REFERRALS')




       
       



    })

    it.only('should be able to update profile', ()=>{
        cy.visit('https://dispensed.scssconsultingapps.com.au/accounts/login/')
        
        referal.Email().type("sandesh@scssconsulting.com")
        referal.Password().type('hellonepal')
         referal.clickButton().click({force:true})
         cy.contains('Discount my Treatment').click()
         cy.get('class="nav-link"]').should('contain','Referrals').click()


})})