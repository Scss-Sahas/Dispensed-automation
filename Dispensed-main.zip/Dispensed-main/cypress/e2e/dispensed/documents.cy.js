import { docs } from "../../support/dispensed/documents.po"

describe('Documents', () => {
    it('should able to download the file', ()=>{
      cy.visit('https://dispensed.scssconsultingapps.com.au/accounts/login/')
      
      docs.Email().type("sandesh@test.com")
      docs.Password().type('hellonepal')
       docs.clickButton().click({force:true})
       cy.contains('Documents').click()
      cy.get('[class="fw-bold mb-4"]') .should('contain', 'All Documents')
      docs.downloadButton().first().click()
       



    })
    it('should able to uplode the file', ()=>{
        cy.visit('https://dispensed.scssconsultingapps.com.au/accounts/login/')
        
        docs.Email().type("sandesh@test.com")
        docs.Password().type('hellonepal')
         docs.clickButton().click({force:true})
         cy.contains('Documents').click()
        cy.contains('Document Upload').click()
       //cy.visit('["href="?page=Document Upload"]').click()
       Cypress.on('uncaught:exception', (err, runnable) => {
        return false
        })
        cy.get('[class="btn btn-dark mb-3 btn-submit btn-3-rem"]').click()

})
})