import { Profile } from "../../support/dispensed/profile.po"

describe('Profile', () => {
    it('Profile update', ()=>{
      cy.visit('https://dispensed.scssconsultingapps.com.au/accounts/login/')
      
      Profile.Email().type("sandesh@test.com")
      Profile.Password().type('hellonepal')
       Profile.clickButton().click({force:true})
       cy.contains('Profile').click()
       
       Profile.firstName().clear().type('harry')
       Profile.lastName().clear().type('aryal')
       Profile.saveButton().click()



    })
    it('checks the date validation', ()=>{
        cy.visit('https://dispensed.scssconsultingapps.com.au/accounts/login/')
        
        Profile.Email().type("sandesh@test.com")
        Profile.Password().type('hellonepal')
         Profile.clickButton().click({force:true})
         cy.contains('Profile').click()
         Profile.selectDob().click()

         Profile.selectDob().type("2022-04-02")
         Profile.saveButton().click({force:true})
         cy.get('[id="error_1_id_dob"]').should('contain', 'Must be at least 16 years old to register')

        

  
  
  
      })})
  

